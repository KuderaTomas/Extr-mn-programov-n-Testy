﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace epickyextremniprg
{
    class HerniPostava
    {
        private string jmeno;
        public string Jmeno
        {
            get
            {
                return jmeno;
            }
            set
            {
                jmeno = value;
                if(jmeno.Length>10)
                {
                    MessageBox.Show("Příliš dlouhé jméno!");
                    jmeno = "";
                }
            }
        }
        private int levl=1;
        public int Levl
        {
            get;
            set;
        }
        private int poziceX;
        public int PoziceX
        {
            get
            {
                poziceX = 0;
                return poziceX;
            }
        }
        private int poziceY;
        public int PoziceY
        {
            get
            {
                poziceY = 0;
                return poziceY;
            }
        }
        public HerniPostava(string jmeno)
        {
            Jmeno = jmeno;
        }
        public void ZmenaPozice(int x, int y)
        {
            poziceX = x;
            poziceY = y;
        }
        public override string ToString()
        {
            return "Jméno: " + jmeno + "\nLevl: " + levl + "\nPoziceX: " + poziceX + "\nPoziceY: " + poziceY;
        }
    }
}
