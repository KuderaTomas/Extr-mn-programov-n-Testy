﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace epickyextremniprg
{
    class Hrac:HerniPostava
    {
        private string specializace;
        public string Specializace
        {
            get
            {
                return specializace;
            }
            set
            {
                specializace = value;
                if(specializace !="Kouzelník"&& specializace != "Berserk" && specializace != "Inženýr" && specializace != "Cizák")
                {
                    MessageBox.Show("Špatná specializace.");
                    specializace = "";
                }
            }

        }

        public enum oblicej
        {
            velký_nos, ušoplesk, make_up
        }
        public enum vlasy
        {
            culík, drdol, pleška
        }
        public enum barvaVlasu
        {
            kaštanová, blond, červená
        }
        public int XP = 0;
        
        public Hrac(string jmeno, string specializace, oblicej obl, vlasy vls, barvaVlasu bvls ) :base(jmeno)
        {
            Specializace = specializace;
            obl = 0;
            vls = 0;
            bvls = 0;
        }
       public void PridejXP(double xp)
        {
            if (100 * Levl == xp)
                Levl++;
      
        }

        public override string ToString()
        {
            return "Jméno" + Jmeno +  "\nLevel:" + Levl + "\nXP:" + XP + "\nSpecializace" + specializace + "\nObličej" + oblicej.make_up.ToString() + "\nVlasy" + vlasy.culík.ToString() + "\nBarva vlasů:" + barvaVlasu.blond.ToString();
        }
    }
}
