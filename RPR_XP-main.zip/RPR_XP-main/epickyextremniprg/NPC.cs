﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace epickyextremniprg
{
    class NPC : HerniPostava
    {
        public enum prace
        {
            obchodník, nepřítel, obyvatel
        }

        private string sila;
        public string Sila
        {
            get
            {
                return sila;
            }
            set
            {
                sila = value;
                if(sila!="BOSS"&&sila!="ne")
                {
                    MessageBox.Show("Špatně zadaná síla.");
                    sila = "";
                }
            }
        }
        public NPC(string jmeno, prace pr) : base(jmeno)
        {
            pr = 0;
            Sila = "ne";
        }
        public static void ZmenaPozice(int x, int y)
        {
            
        }
        public override string ToString()
        {
            return "Jméno " + Jmeno + "\nPráce " + prace.nepřítel.ToString() + "\nSíla " + sila + "\nPoziceX " + PoziceX + "\nPozice Y" + PoziceY; 
        }
    }
}
